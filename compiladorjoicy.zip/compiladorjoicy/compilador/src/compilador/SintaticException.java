package compilador;

public class SintaticException extends RuntimeException {
    public SintaticException(String message) {
        super (message);
    }
}
