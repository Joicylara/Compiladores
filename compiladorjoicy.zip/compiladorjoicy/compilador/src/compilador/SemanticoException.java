package compilador;

public class SemanticoException extends RuntimeException{
        public SemanticoException(String message) {
            super(message);
        }
}
