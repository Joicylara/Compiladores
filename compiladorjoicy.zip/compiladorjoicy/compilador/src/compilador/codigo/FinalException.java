package compilador.codigo;


public class FinalException extends Exception {
    public FinalException (String message){
        super (message);
    }
}
