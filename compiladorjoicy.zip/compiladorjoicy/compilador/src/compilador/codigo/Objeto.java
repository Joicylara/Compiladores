package compilador.codigo;


public class Objeto {
    public String val0;
    public String val1;
    public String val2;

    
    public Objeto(String val0, String val1, String val2) {
        this.val0 = val0;
        this.val1 = val1;
        this.val2 = val2;
    }

}
